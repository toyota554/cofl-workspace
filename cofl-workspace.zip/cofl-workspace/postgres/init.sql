-- ─────────────────────────────────────────────────────────────────
-- COFL PostgreSQL Schema Initialization
-- Monitor stage: event_log + daily_metrics tables
-- Reference: Chen et al., MDPI Information 2026 — §3.4
-- ─────────────────────────────────────────────────────────────────

-- Event log: stores every Analyze and Generate interaction
CREATE TABLE IF NOT EXISTS event_log (
    id          BIGSERIAL PRIMARY KEY,
    order_id    TEXT        NOT NULL,
    stage       TEXT        NOT NULL CHECK (stage IN ('analyze', 'generate', 'escalation')),
    payload     JSONB       NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_event_log_order_id    ON event_log (order_id);
CREATE INDEX IF NOT EXISTS idx_event_log_stage       ON event_log (stage);
CREATE INDEX IF NOT EXISTS idx_event_log_created_at  ON event_log (created_at DESC);

-- Escalation queue: routes LLM inference timeouts to human review
CREATE TABLE IF NOT EXISTS escalation_queue (
    id          BIGSERIAL PRIMARY KEY,
    order_id    TEXT        NOT NULL,
    reason      TEXT        NOT NULL,
    original_text TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ
);

-- Daily metrics: aggregated by nightly cron workflow in n8n
-- Operational Monitoring Workflow (paper §3.4)
CREATE TABLE IF NOT EXISTS daily_metrics (
    id              BIGSERIAL PRIMARY KEY,
    metric_date     DATE        NOT NULL UNIQUE,
    total_events    INT         NOT NULL DEFAULT 0,
    negative_count  INT         NOT NULL DEFAULT 0,
    neutral_count   INT         NOT NULL DEFAULT 0,
    positive_count  INT         NOT NULL DEFAULT 0,
    responses_sent  INT         NOT NULL DEFAULT 0,
    escalations     INT         NOT NULL DEFAULT 0,
    avg_analyze_ms  NUMERIC(8,2),
    avg_generate_ms NUMERIC(8,2),
    parse_failures  INT         NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- View: today's live summary (convenient for n8n PostgreSQL node queries)
CREATE OR REPLACE VIEW v_today_summary AS
SELECT
    COUNT(*)                                          AS total_events,
    COUNT(*) FILTER (WHERE payload->>'sentiment_label' = 'negative') AS negative_count,
    COUNT(*) FILTER (WHERE payload->>'sentiment_label' = 'neutral')  AS neutral_count,
    COUNT(*) FILTER (WHERE payload->>'sentiment_label' = 'positive') AS positive_count,
    AVG((payload->>'latency_ms')::int)
        FILTER (WHERE stage = 'analyze')              AS avg_analyze_ms,
    AVG((payload->>'latency_ms')::int)
        FILTER (WHERE stage = 'generate')             AS avg_generate_ms
FROM event_log
WHERE created_at >= CURRENT_DATE;
