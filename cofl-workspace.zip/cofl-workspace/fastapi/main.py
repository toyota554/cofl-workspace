"""
COFL FastAPI Asynchronous Microservice Gateway
================================================
Reference: Chen et al., "Designing a Continuous Operational Feedback Loop
for Direct-to-Consumer Commerce", MDPI Information, 2026 — §3.5

Exposes two async endpoints served by a four-worker Uvicorn process pool:
  POST /analyze  — Zero-shot sentiment classification via Ollama LLM
  POST /generate — Role-conditioned response generation (triggered when
                   sentiment_score < SENTIMENT_THRESHOLD)
"""

import os
import re
import time
import logging
from datetime import datetime, timezone

import httpx
import psycopg2
from psycopg2.extras import RealDictCursor
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel

# ─── Configuration ────────────────────────────────────────────────────────────
OLLAMA_BASE_URL   = os.getenv("OLLAMA_BASE_URL", "http://ollama:11434")
OLLAMA_MODEL      = os.getenv("OLLAMA_MODEL", "llama3:8b-instruct-q4_K_M")
POSTGRES_DSN      = os.getenv("POSTGRES_DSN", "")
LLM_TEMPERATURE   = float(os.getenv("LLM_TEMPERATURE", "0.1"))
SENTIMENT_THRESHOLD = float(os.getenv("SENTIMENT_THRESHOLD", "0.35"))
GENERATE_MAX_WORDS  = int(os.getenv("GENERATE_MAX_WORDS", "150"))

# LLM serving parameters (paper §3.6)
CONTEXT_WINDOW  = 4096
NUM_PREDICT     = 256
REPEAT_PENALTY  = 1.1

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("cofl")

# ─── FastAPI App ──────────────────────────────────────────────────────────────
app = FastAPI(
    title="COFL FastAPI Gateway",
    description=(
        "Continuous Operational Feedback Loop — FastAPI microservice bridging "
        "the n8n workflow engine with on-premise Ollama LLM inference. "
        "Reference implementation for MDPI Information 2026."
    ),
    version="1.0.0",
)

# ─── Pydantic Schemas ─────────────────────────────────────────────────────────

class AnalyzeRequest(BaseModel):
    text: str
    order_id: str
    star_rating: int | None = None

class AnalyzeResponse(BaseModel):
    order_id: str
    sentiment_label: str       # "negative" | "neutral" | "positive"
    sentiment_score: float     # 0.0 (most negative) – 1.0 (most positive)
    category: str              # complaint category
    requires_response: bool    # True when sentiment_score < SENTIMENT_THRESHOLD
    latency_ms: int

class GenerateRequest(BaseModel):
    order_id: str
    original_text: str
    sentiment_label: str
    category: str

class GenerateResponse(BaseModel):
    order_id: str
    generated_reply: str
    word_count: int
    latency_ms: int

# ─── Database Helper ──────────────────────────────────────────────────────────

def get_db_conn():
    """Return a PostgreSQL connection; returns None if DSN is not configured."""
    if not POSTGRES_DSN:
        return None
    try:
        return psycopg2.connect(POSTGRES_DSN, cursor_factory=RealDictCursor)
    except Exception as exc:
        logger.warning("PostgreSQL connection failed: %s", exc)
        return None

def log_interaction(order_id: str, stage: str, payload: dict) -> None:
    """Persist interaction to the event_log table (Monitor stage of COFL)."""
    conn = get_db_conn()
    if conn is None:
        return
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO event_log (order_id, stage, payload, created_at)
                    VALUES (%s, %s, %s::jsonb, %s)
                    """,
                    (order_id, stage, str(payload).replace("'", '"'), datetime.now(timezone.utc)),
                )
    except Exception as exc:
        logger.warning("event_log write failed: %s", exc)
    finally:
        conn.close()

# ─── Prompt Templates ─────────────────────────────────────────────────────────

def build_analyze_prompt(text: str) -> str:
    """
    Zero-shot classification prompt (paper §3.5).
    Temperature is set to 0.1 to maximize classification determinism.
    """
    return (
        "You are a sentiment analysis engine for an e-commerce platform. "
        "Classify the following customer message into one of three categories: "
        "NEGATIVE, NEUTRAL, or POSITIVE. "
        "Also identify the complaint category from: "
        "product_defect, shipping_delay, return_refund, neutral_inquiry, positive_review. "
        "Output ONLY in this exact format on two lines:\n"
        "SENTIMENT: <NEGATIVE|NEUTRAL|POSITIVE>\n"
        "CATEGORY: <category>\n\n"
        f"Customer message: {text}"
    )

def build_generate_prompt(original_text: str, sentiment_label: str, category: str) -> str:
    """
    Role-conditioned response generation prompt (paper §3.5).
    - Professional customer service persona
    - Maximum GENERATE_MAX_WORDS words
    - Mandatory complaint-category acknowledgment
    - Concrete remediation offer required
    """
    return (
        "You are a professional customer service representative for an e-commerce company. "
        "Your response must:\n"
        f"1. Acknowledge the customer's {category.replace('_', ' ')} issue\n"
        "2. Sincerely apologize for the inconvenience\n"
        "3. Provide a CONCRETE remediation offer (e.g., replacement, full refund, discount code)\n"
        f"4. Be no longer than {GENERATE_MAX_WORDS} words\n"
        "5. Maintain a professional, empathetic tone\n\n"
        f"Customer complaint (sentiment: {sentiment_label}):\n{original_text}\n\n"
        "Write your customer service response:"
    )

# ─── Regex-Based Response Parser ──────────────────────────────────────────────

SENTIMENT_RE = re.compile(r"SENTIMENT:\s*(NEGATIVE|NEUTRAL|POSITIVE)", re.IGNORECASE)
CATEGORY_RE  = re.compile(
    r"CATEGORY:\s*(product_defect|shipping_delay|return_refund|neutral_inquiry|positive_review)",
    re.IGNORECASE,
)

SCORE_MAP = {"negative": 0.10, "neutral": 0.55, "positive": 0.90}

def parse_sentiment_response(raw: str) -> tuple[str, float, str]:
    """
    Parse LLM output with regex; returns (label, score, category).
    Falls back gracefully on parse failure (observed rate: 2.3%, paper §3.5).
    """
    sentiment_match = SENTIMENT_RE.search(raw)
    category_match  = CATEGORY_RE.search(raw)

    label    = sentiment_match.group(1).lower() if sentiment_match else "neutral"
    category = category_match.group(1).lower()  if category_match  else "neutral_inquiry"
    score    = SCORE_MAP.get(label, 0.55)

    if not sentiment_match:
        logger.warning("Sentiment parse failed; raw output: %s", raw[:200])

    return label, score, category

# ─── Ollama API Client ────────────────────────────────────────────────────────

async def call_ollama(prompt: str, temperature: float = LLM_TEMPERATURE) -> str:
    """
    Call the Ollama /api/generate endpoint asynchronously.
    Model serving parameters from paper §3.6:
      context_window = 4096, num_predict = 256, repeat_penalty = 1.1
    System prompt caching is enabled by Ollama by default.
    """
    payload = {
        "model": OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": temperature,
            "num_ctx":     CONTEXT_WINDOW,
            "num_predict": NUM_PREDICT,
            "repeat_penalty": REPEAT_PENALTY,
        },
    }
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(f"{OLLAMA_BASE_URL}/api/generate", json=payload)
        resp.raise_for_status()
        data = resp.json()
        return data.get("response", "").strip()

# ─── Endpoints ────────────────────────────────────────────────────────────────

@app.get("/health", tags=["System"])
async def health_check():
    """Health probe for Docker Compose and load balancers."""
    return {"status": "ok", "model": OLLAMA_MODEL, "threshold": SENTIMENT_THRESHOLD}


@app.post("/analyze", response_model=AnalyzeResponse, tags=["COFL"])
async def analyze(req: AnalyzeRequest):
    """
    COFL Stage 2 — Analyze
    ----------------------
    Receives customer complaint text from n8n, dispatches to Ollama for
    zero-shot sentiment classification, and returns a structured result.

    Triggered by: n8n Complaint Triage Workflow (Webhook → HTTP Request node)
    Threshold:    sentiment_score < SENTIMENT_THRESHOLD (default 0.35) triggers /generate
    """
    t0 = time.perf_counter()

    prompt = build_analyze_prompt(req.text)

    try:
        raw_output = await call_ollama(prompt, temperature=LLM_TEMPERATURE)
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="LLM inference timeout (>30s)")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"Ollama error: {exc.response.status_code}")

    label, score, category = parse_sentiment_response(raw_output)
    latency_ms = int((time.perf_counter() - t0) * 1000)

    result = AnalyzeResponse(
        order_id=req.order_id,
        sentiment_label=label,
        sentiment_score=score,
        category=category,
        requires_response=(score < SENTIMENT_THRESHOLD),
        latency_ms=latency_ms,
    )

    # Monitor stage: persist to PostgreSQL event log
    log_interaction(req.order_id, "analyze", result.model_dump())

    logger.info(
        "ANALYZE order=%s label=%s score=%.2f category=%s latency=%dms",
        req.order_id, label, score, category, latency_ms,
    )
    return result


@app.post("/generate", response_model=GenerateResponse, tags=["COFL"])
async def generate(req: GenerateRequest):
    """
    COFL Stage 3 — Act
    ------------------
    Invoked when sentiment_score < SENTIMENT_THRESHOLD (0.35).
    Uses role-conditioned prompt to generate a professional customer service
    reply with a concrete remediation offer, capped at GENERATE_MAX_WORDS words.

    Triggered by: n8n Switch node routing negative sentiment to this endpoint
    """
    t0 = time.perf_counter()

    prompt = build_generate_prompt(req.original_text, req.sentiment_label, req.category)

    try:
        raw_reply = await call_ollama(prompt, temperature=LLM_TEMPERATURE)
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="LLM inference timeout (>30s)")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"Ollama error: {exc.response.status_code}")

    # Enforce word count limit
    words = raw_reply.split()
    if len(words) > GENERATE_MAX_WORDS:
        raw_reply = " ".join(words[:GENERATE_MAX_WORDS])

    latency_ms = int((time.perf_counter() - t0) * 1000)

    result = GenerateResponse(
        order_id=req.order_id,
        generated_reply=raw_reply,
        word_count=len(raw_reply.split()),
        latency_ms=latency_ms,
    )

    # Monitor stage: persist to PostgreSQL event log
    log_interaction(req.order_id, "generate", result.model_dump())

    logger.info(
        "GENERATE order=%s words=%d latency=%dms",
        req.order_id, result.word_count, latency_ms,
    )
    return result
