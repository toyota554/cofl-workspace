# COFL Architecture Documentation

## Overview

The Continuous Operational Feedback Loop (COFL) maps classical closed-loop control theory onto D2C e-commerce intelligence:

| Control Theory Stage | COFL Stage | Implementation |
|---|---|---|
| Reference Input | **Sense** | n8n Webhook trigger |
| Error Detection | **Analyze** | FastAPI → Ollama LLM sentiment classification |
| Actuator Response | **Act** | FastAPI → Ollama response generation |
| Output Feedback | **Monitor** | PostgreSQL event log + nightly metrics |

---

## Service Configuration Details

### Ollama (Port 11434)

- **Image:** `ollama/ollama:latest`
- **Model:** LLaMA 3 8B Q4_K_M (GGUF, 4.65 GB)
- **Serving parameters:**
  - `context_window = 4096` tokens
  - `num_predict = 256` tokens max
  - `repeat_penalty = 1.1`
  - System prompt caching: **enabled**
- **Throughput (i5-12400F):** ~17.2 tok/s
- **Hardware boundary model:** throughput ∝ memory_bandwidth / model_size
  - At 51.2 GB/s bandwidth: predicted 17.6 tok/s; measured 17.2 tok/s (2.3% error)

### FastAPI Gateway (Port 8000)

- **Base image:** `python:3.11-slim`
- **Framework:** FastAPI 0.110.0 + Uvicorn 0.29.0
- **Workers:** 4 async (Uvicorn process pool)
- **Inference temperature:** 0.1 (maximizes classification determinism)
- **Parse failure rate:** 2.3% (regex fallback re-prompt mechanism)
- **Timeout:** 30 seconds per Ollama call

### n8n (Port 5678)

- **Image:** `n8nio/n8n:1.32.0`
- **Webhook URL:** `http://<host>:5678/webhook/cofl-complaint`
- **Complaint Triage trigger:** `star_rating ≤ 2` OR explicit complaint flag
- **Response Generation trigger:** `sentiment_score < 0.35`
- **Nightly Monitoring cron:** aggregates 24-hour metrics to `daily_metrics` table

### PostgreSQL (Port 5432)

- **Image:** `postgres:15-alpine`
- **Tables:** `event_log`, `escalation_queue`, `daily_metrics`
- **View:** `v_today_summary` — live dashboard query for n8n monitoring node
- **Connection pool:** pgBouncer (max 20 connections) for robustness

---

## Quantization Ablation Results (Table 7)

The ablation study across six configurations confirms Q4_K_M as Pareto-optimal:

| Model | Quant | Size | Tok/s | F1 | ROUGE-L | Notes |
|---|---|---|---|---|---|---|
| **LLaMA 3 8B** | **Q4_K_M** ✓ | **4.65 GB** | **17.2** | **0.836** | **0.421** | **Selected** |
| LLaMA 3 8B | Q5_K_M | 5.33 GB | 13.8 | 0.841 | 0.427 | +0.6% F1, −19.8% speed |
| LLaMA 3 8B | Q8_0 | 8.54 GB | 8.4 | 0.847 | 0.433 | 51% speed reduction |
| LLaMA 3 8B | F16 | 15.3 GB | 3.1 | 0.851 | 0.439 | Baseline reference |
| Mistral 7B | Q4_K_M | 4.11 GB | 19.6 | 0.821 | 0.412 | Lower F1, higher speed |
| Phi-3 3.8B | Q4_K_M | 2.30 GB | 24.1 | 0.798 | 0.388 | −6.3 pp F1 vs selected |

**Q4_K_M achieves 98.2% of full-precision F1 at 5.5× throughput.**

---

## AHP Evaluation Framework

Five criteria with literature-grounded weights (CR = 0.047 < 0.10):

| Criterion | Weight | COFL Score | Cloud Score |
|---|---|---|---|
| C1: Latency | 0.143 | 8.2 | 8.8 |
| C2: Data Privacy | 0.362 | **9.5** | 3.5 |
| C3: Generation Accuracy | 0.249 | 8.0 | 9.0 |
| C4: Total Cost of Ownership | 0.078 | 9.1 | 7.5 |
| C5: Scalability | 0.168 | 7.8 | 9.2 |
| **Composite** | | **8.89** | **6.58** |

COFL advantage is maintained for all C2 > 0.22 (sensitivity analysis).

---

## Dataset Construction (N = 1,800)

| Category | Count | Proportion | Source |
|---|---|---|---|
| Product Defect | 456 | 25% | Amazon Product Reviews |
| Shipping Delay | 408 | 23% | Shopee TW Review Corpus |
| Return/Refund | 336 | 19% | Bilingual e-commerce corpus |
| Neutral Inquiry | 400 | 22% | E-commerce FAQ logs |
| Positive Review | 200 | 11% | Amazon 5-star subset |

**Automated labeling pipeline:** VADER + TextBlob + GPT-4o majority vote.
Agreement rate: 98.3%. Excluded (all three disagreed): n=41 (2.3%).

---

## 36-Month TCO Comparison (10,000 interactions/month)

| Cost Component | COFL Local | Cloud GPT-4o |
|---|---|---|
| Hardware (amortized) | NT$1,458/mo | NT$0 |
| Inference cost | NT$900/mo | NT$180,000/mo |
| Electricity | NT$140/mo | NT$0 |
| Maintenance | NT$1,200/mo | NT$0 |
| **Monthly total** | **NT$3,698** | **~NT$180,200** |
| **36-month total** | **~NT$133,000** | **~NT$6,490,000** |

**Cost advantage: 48× in favor of COFL.**
