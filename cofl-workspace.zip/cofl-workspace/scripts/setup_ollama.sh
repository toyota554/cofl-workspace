#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# COFL — Ollama Model Setup Script
# Downloads and verifies LLaMA 3 8B Q4_K_M: the Pareto-optimal model
# for CPU-only inference validated in the ablation study (paper §4.3).
#
# Quantization stats (from Table 7):
#   Size:  4.65 GB  |  Throughput: 17.2 tok/s  |  F1: 0.836  |  ROUGE-L: 0.421
#   = 98.2% of full-precision F1 at 5.5× throughput improvement
#
# Hardware requirement: ≥ 32 GB RAM (model occupies ~4.65 GB;
#   system steady-state ~13.8 GB at peak load)
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

CONTAINER_NAME="${OLLAMA_CONTAINER:-cofl-ollama}"
MODEL_NAME="llama3:8b-instruct-q4_K_M"

echo "══════════════════════════════════════════════════════"
echo "  COFL — Ollama Model Setup"
echo "  Target model: ${MODEL_NAME}"
echo "  Container:    ${CONTAINER_NAME}"
echo "══════════════════════════════════════════════════════"

# ── Wait for Ollama container to be healthy ────────────────────────────────
echo ""
echo "▶ Waiting for Ollama container to be ready..."
until docker exec "${CONTAINER_NAME}" curl -sf http://localhost:11434/api/tags > /dev/null 2>&1; do
    echo "  … not ready yet, retrying in 3s"
    sleep 3
done
echo "  ✓ Ollama is ready."

# ── Pull the model ────────────────────────────────────────────────────────
echo ""
echo "▶ Pulling ${MODEL_NAME} (4.65 GB — this may take several minutes)..."
docker exec "${CONTAINER_NAME}" ollama pull "${MODEL_NAME}"
echo "  ✓ Model pulled."

# ── Verify the model is listed ────────────────────────────────────────────
echo ""
echo "▶ Verifying model registration..."
docker exec "${CONTAINER_NAME}" ollama list | grep -i "llama3" && echo "  ✓ Model verified."

# ── Quick inference smoke test ────────────────────────────────────────────
echo ""
echo "▶ Running smoke test (single inference call)..."
RESPONSE=$(docker exec "${CONTAINER_NAME}" ollama run "${MODEL_NAME}" \
    "Reply with exactly: SENTIMENT: POSITIVE" 2>&1 | head -5)
echo "  Response: ${RESPONSE}"
echo "  ✓ Smoke test complete."

echo ""
echo "══════════════════════════════════════════════════════"
echo "  Setup complete."
echo ""
echo "  Model serving parameters (paper §3.6):"
echo "    context_window = 4096 tokens"
echo "    num_predict    = 256 tokens max"
echo "    repeat_penalty = 1.1"
echo "    system prompt caching: enabled"
echo ""
echo "  Predicted throughput on i5-12400F: ~17.2 tok/s"
echo "  Expected E2E latency: ~3.22 s (paper Table 6)"
echo "══════════════════════════════════════════════════════"
